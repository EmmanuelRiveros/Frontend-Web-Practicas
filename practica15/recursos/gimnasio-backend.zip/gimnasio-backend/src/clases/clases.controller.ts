import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  NotFoundException,
  Param,
  ParseIntPipe,
  Patch,
  Post,
} from '@nestjs/common';
import { Publico } from '../auth/decoradores/publico.decorator';
import { ClasesService } from './clases.service';
import { CrearClaseDto } from './dto/crear-clase.dto';
import { ActualizarClaseDto } from './dto/actualizar-clase.dto';

@Controller('clases')
export class ClasesController {
  constructor(private readonly clasesService: ClasesService) {}

  /** GET /clases */
  @Publico() // el catalogo lo ve cualquiera, sin cuenta
  @Get()
  listar() {
    return this.clasesService.listar();
  }

  /** GET /clases/2 */
  @Publico()
  @Get(':id')
  async buscar(@Param('id', ParseIntPipe) id: number) {
    // Regresa la clase con sus horarios y lugares libres.
    // ParseIntPipe: /clases/abc responde 400, no un 500 de Prisma.
    const clase = await this.clasesService.buscarConHorarios(id);
    if (!clase) {
      throw new NotFoundException(`No existe la clase ${id}`);
    }
    return clase;
  }

  /** POST /clases */
  @Post()
  @HttpCode(201)
  crear(@Body() dto: CrearClaseDto) {
    return this.clasesService.crear(dto);
  }

  /** PATCH /clases/2 */
  @Patch(':id')
  async actualizar(@Param('id') id: string, @Body() dto: ActualizarClaseDto) {
    const clase = await this.clasesService.actualizar(Number(id), dto);
    if (!clase) {
      throw new NotFoundException(`No existe la clase ${id}`);
    }
    return clase;
  }

  /** DELETE /clases/2 */
  @Delete(':id')
  async eliminar(@Param('id') id: string) {
    const clase = await this.clasesService.eliminar(Number(id));
    if (!clase) {
      throw new NotFoundException(`No existe la clase ${id}`);
    }
    return clase;
  }
}
